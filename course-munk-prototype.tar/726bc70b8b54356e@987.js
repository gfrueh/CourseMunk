import define1 from "./df13f6b833284913@175.js";

function _1(md){return(
md`# C🍩urse Munk

Testable interactive prototype (4/27)

Hello! Welcome to CourseMunk, a visualization about courses at DIS. Every student in the Data Visualization course at DIS answered a survey about the courses they are taking this semester, and we have compiled the results in the parallel coordinate and donut charts below. Based on student experiences, we hope to provide feedback to DIS on the quality, usefulness, enjoyment, and difficulty of their courses. This may also help future students plan their schedules as well.

Thank you for agreeing to participate in this testing session. Please fill out this feedback form while you complete the tasks below:

https://forms.gle/J5VKZxywoT1VVDoK8

Your task:

Choose a course that interests you and answer the questions.

Tip: To get the clearest highlighting on the parallel coordinates chart, click the donut before hovering over the class of interest. Or hover off the slice for a few seconds and slowly hover back on.

Your answers will be used only by us to improve the design.

Thanks!
`
)}

function _2(md){return(
md`----`
)}

function _swatch(Swatches,d3,category){return(
Swatches(d3.scaleOrdinal(category, d3.schemeSet2), {
  columns: "180px",
  swatchSize: 30

})
)}

function _4(md){return(
md`----`
)}

function _5(donutchart){return(
donutchart
)}

function _6(md){return(
md`----`
)}

function _parallelchart(d3,width,height,y,x,margin,data,keys)
{
  const svg = d3.create("svg")
      .attr("viewBox", [0, 0, width, height]);
  
  //line generator
  let line = d3.line()
    .defined(([, value]) => value != null)
    .y(([key, value]) => y[key](value))
    .x(([key]) => x(key))

  //data lines
  svg.append("g")
      .attr("transform", `translate(0, ${margin.top})`)
      .attr("fill", "none")
      .attr("stroke-width", 2)
      .attr("stroke-opacity", 1)
    .selectAll("path")
    .data(data.slice().sort((a, b) => d3.ascending(a[keys], b[keys])))
    .join("path")
      .attr("class", "dataline")
      .attr("stroke", d => d.Color)
      .attr("d", d => line(d3.cross(keys, [d], (key, d) => [key, d[key]]))) //generated line
    .append("title")
      .text(d => d.name);
  
  //axes
  svg.append("g")
    .selectAll("g")
    .data(keys)
    .join("g")
      .attr("transform", d => `translate( ${x(d)} , ${margin.top})`)
      .each(function(d) { d3.select(this).call(d3.axisLeft(y[d]).ticks(5)); })
      .call(g => g.append("text")
        .attr("x", 0)
        .attr("y", 0)
        .attr("text-anchor", "middle")
        .attr("fill", "currentColor")
        .style("font-size", "16px")
        .text(d => d))
      .call(g => g.selectAll("text")
        //.attr('transform', 'rotate(-30)')
        .clone(true).lower()
        .attr("fill", "none")
        .attr("stroke-width", 5)
        .attr("stroke-linejoin", "round")
        .attr("stroke", "white"));
 
  return svg.node();
}


function _8(md){return(
md`----
## Getting the data

Below i replaced the data to a custom google sheet. I demonstrated this trick in class once, see first answer [here](https://stackoverflow.com/questions/33713084/download-link-for-google-spreadsheets-csv-export-with-multiple-sheets)`
)}

function _linkToSpreadsheet(){return(
"https://docs.google.com/spreadsheets/d/1HdATGSycXsz0DWcUAd8fLfAHEuInhrGgl835nR0brVQ/gviz/tq?tqx=out:csv&sheet=Sheet5"
)}

function _data(d3,linkToSpreadsheet){return(
d3.csv(linkToSpreadsheet)
)}

function _col(data){return(
data.columns
)}

function _keys(col){return(
col.slice(0,6)
)}

function _13(md){return(
md`----
## Creating scales
Here i modified the original code in order to support parallel coordinates for nominal and ordinal data`
)}

function _types(keys,data)
{
  let types = {};
  keys.forEach(key => types[key] = isNaN(+data[0][key]) ? "string" : "number")
  return types;
}


function _15(md){return(
md`### Horizontal scale for all the axes:`
)}

function _x(d3,keys,margin,width){return(
d3.scalePoint(keys, [margin.left, width - margin.right])
)}

function _17(md){return(
md`### A set of Y scales:`
)}

function _y(types,d3,data,keys,height,margin)
{
  let getXScale = (key) => types[key] === "number"
    ? d3.scaleLinear()
    : d3.scalePoint().padding(0);
  
  let getXdomain = (key) => types[key] === "number"
    ? d3.extent(data, d => d[key])
    : [... new Set(data.map(m => m[key]))];
  
  let scales = {};
  keys.forEach(key => {
    scales[key] = getXScale(key)
      .domain(getXdomain(key))
      .range([height - margin.bottom, margin.top])
  })
  return scales;
}


function _19(md){return(
md`----
## Interaction`
)}

function _20(d3,donutchart,html,parallelchart,coursenames)
{

  // this is what you should be doing... see what "debug" returns. 
  // do you need help understanding d3 selections? it's important because it's one of the cornerstones in d3
  const slices = d3.select(donutchart)
      .selectAll("path")

  // make text elements transparent for mouse pointer
  const texts = d3.select(donutchart)
      .selectAll("text")
      .style("pointer-events", "none")
  
  const debug = html`<p>${slices.size()} slices selected</p>`;


  //same with lines
  const lines = d3.select(parallelchart)
    .selectAll(".dataline"); //note the added class "dataline" in the parallel coordinates chart

  slices.on("mouseover", function(event, d) {
    d3.select(this)
      .transition()
      .style("fill", "red");
    
    lines.filter(e => {
      console.log(d, e)  // open dev tools and use console.log to see how it works, what are d and e?
      return coursenames[d.data].Name === e.Name; 
    })
      .raise()
      .transition()
      .style("stroke", "red")
      .style("stroke-width", "5");
    
    d3.select(debug).text(`Bar: ${coursenames[d.data].Name}`);
  });
  
  slices.on("mouseout", function(event, d) {
    d3.select(this)
      .transition()
      .style("fill", donutchart.scales.color(coursenames[d.data].Category)); 

    //donutchart.scales.color()
    
    lines
      .style("stroke-width", "2")
      .style("stroke", d => d.Color); //change color of all data lines back (code copied from parallel coordinates)
  });
  
  return debug;
}


function _21(md){return(
md`----
## Appendix`
)}

function _d3(require){return(
require("d3@6")
)}

function _height(keys){return(
keys.length * 120
)}

function _margin(){return(
{top: 20, right: 150, bottom: 30, left: 300}
)}

function _Swatches(d3,htl){return(
function Swatches(color, {
  columns = null,
  format,
  unknown: formatUnknown,
  swatchSize = 15,
  swatchWidth = swatchSize,
  swatchHeight = swatchSize,
  marginLeft = 0
} = {}) {
  const id = `-swatches-${Math.random().toString(16).slice(2)}`;
  const unknown = formatUnknown == null ? undefined : color.unknown();
  const unknowns = unknown == null || unknown === d3.scaleImplicit ? [] : [unknown];
  const domain = color.domain().concat(unknowns);
  if (format === undefined) format = x => x === unknown ? formatUnknown : x;

  function entity(character) {
    return `&#${character.charCodeAt(0).toString()};`;
  }

  if (columns !== null) return htl.html`<div style="display: flex; align-items: center; margin-left: ${+marginLeft}px; min-height: 35px; font: 20px sans-serif;">
  <style>

.${id}-item {
  break-inside: avoid;
  display: flex;
  align-items: center;
  padding-bottom: 1px;
}

.${id}-label {
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
  max-width: calc(100% - ${+swatchWidth}px - 0.5em);
}

.${id}-swatch {
  width: ${+swatchWidth}px;
  height: ${+swatchHeight}px;
  margin: 0 0.5em 0 0;
}

  </style>
  <div style=${{width: "100%", columns}}>${domain.map(value => {
    const label = `${format(value)}`;
    return htl.html`<div class=${id}-item>
      <div class=${id}-swatch style=${{background: color(value)}}></div>
      <div class=${id}-label title=${label}>${label}</div>
    </div>`;
  })}
  </div>
</div>`;

  return htl.html`<div style="display: flex; align-items: center; min-height: 33px; margin-left: ${+marginLeft}px; font: 10px sans-serif;">
  <style>

.${id} {
  display: inline-flex;
  align-items: center;
  margin-right: 1em;
}

.${id}::before {
  content: "";
  width: ${+swatchWidth}px;
  height: ${+swatchHeight}px;
  margin-right: 0.5em;
  background: var(--color);
}

  </style>
  <div>${domain.map(value => htl.html`<span class="${id}" style="--color: ${color(value)}">${format(value)}</span>`)}</div>`;
}
)}

export default function define(runtime, observer) {
  const main = runtime.module();
  main.variable(observer()).define(["md"], _1);
  main.variable(observer()).define(["md"], _2);
  main.variable(observer("swatch")).define("swatch", ["Swatches","d3","category"], _swatch);
  main.variable(observer()).define(["md"], _4);
  main.variable(observer()).define(["donutchart"], _5);
  main.variable(observer()).define(["md"], _6);
  main.variable(observer("parallelchart")).define("parallelchart", ["d3","width","height","y","x","margin","data","keys"], _parallelchart);
  main.variable(observer()).define(["md"], _8);
  main.variable(observer("linkToSpreadsheet")).define("linkToSpreadsheet", _linkToSpreadsheet);
  main.variable(observer("data")).define("data", ["d3","linkToSpreadsheet"], _data);
  main.variable(observer("col")).define("col", ["data"], _col);
  main.variable(observer("keys")).define("keys", ["col"], _keys);
  main.variable(observer()).define(["md"], _13);
  main.variable(observer("types")).define("types", ["keys","data"], _types);
  main.variable(observer()).define(["md"], _15);
  main.variable(observer("x")).define("x", ["d3","keys","margin","width"], _x);
  main.variable(observer()).define(["md"], _17);
  main.variable(observer("y")).define("y", ["types","d3","data","keys","height","margin"], _y);
  main.variable(observer()).define(["md"], _19);
  main.variable(observer()).define(["d3","donutchart","html","parallelchart","coursenames"], _20);
  main.variable(observer()).define(["md"], _21);
  main.variable(observer("d3")).define("d3", ["require"], _d3);
  main.variable(observer("height")).define("height", ["keys"], _height);
  main.variable(observer("margin")).define("margin", _margin);
  main.variable(observer("Swatches")).define("Swatches", ["d3","htl"], _Swatches);
  const child1 = runtime.module(define1);
  main.import("donutchart", child1);
  const child2 = runtime.module(define1);
  main.import("coursenames", child2);
  const child3 = runtime.module(define1);
  main.import("category", child3);
  return main;
}
