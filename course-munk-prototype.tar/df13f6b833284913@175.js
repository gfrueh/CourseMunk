import define1 from "./d8013d8c4457b3eb@515.js";
import define2 from "./a33468b95d0b15b0@808.js";

function _1(md){return(
md`# donut 2`
)}

function _2(md){return(
md`#Donut`
)}

function _swatch(Swatches,d3,category){return(
Swatches(d3.scaleOrdinal(category, d3.schemeSet2), {
  columns: "180px"
})
)}

function _donutchart(DonutChart,coursenames,width,category,d3){return(
DonutChart(coursenames, {
  category: d => d.Category,
  name: d => d.Name,
  value: d => d.Number,
  width,
  height: 800,
  names: category,
  colors: d3.schemeSet2
    //["#8dd3c7", "#ffffb3", "#bebada", "#fb8072", "#80b1d3", "#fdb462", "#b3de69", "#fccde5", "#d9d9d9", "#bc80bd", "#ccebc5", "#ffed6f"]
    //https://observablehq.com/@d3/working-with-color
})
)}

function _linkToSpreadsheet(){return(
"https://docs.google.com/spreadsheets/d/1HdATGSycXsz0DWcUAd8fLfAHEuInhrGgl835nR0brVQ/gviz/tq?tqx=out:csv&sheet=Sheet4"
)}

function _coursenames(d3,linkToSpreadsheet){return(
d3.csv(linkToSpreadsheet)
)}

function _category(coursenames){return(
coursenames.map(d => d.Category)
)}

export default function define(runtime, observer) {
  const main = runtime.module();
  main.variable(observer()).define(["md"], _1);
  main.variable(observer()).define(["md"], _2);
  const child1 = runtime.module(define1);
  main.import("DonutChart", child1);
  main.variable(observer("swatch")).define("swatch", ["Swatches","d3","category"], _swatch);
  main.variable(observer("donutchart")).define("donutchart", ["DonutChart","coursenames","width","category","d3"], _donutchart);
  main.variable(observer("linkToSpreadsheet")).define("linkToSpreadsheet", _linkToSpreadsheet);
  main.variable(observer("coursenames")).define("coursenames", ["d3","linkToSpreadsheet"], _coursenames);
  main.variable(observer("category")).define("category", ["coursenames"], _category);
  const child2 = runtime.module(define2);
  main.import("Swatches", "legend", child2);
  const child3 = runtime.module(define2);
  main.import("Swatches", child3);
  return main;
}
